# Time Profiler 采样摘要

以下为整个进程的 CPU 采样，包含准备、预热和计算。
Weight 是按样本权重估计的累计 CPU 时间，不是墙钟耗时。
多个线程的 CPU 时间可以叠加；调用栈中各函数的 inclusive 权重不能直接相加。
每种策略只有一次 trace；统计性耗时对比应使用未开采样器的独立重复运行。

## serial

样本数：7558；累计采样权重：7558.0 ms；采样到的线程数：1。

| 热点（栈顶 Self Weight） | 权重/ms | 占比 |
|---|---:|---:|
| spmv_serial(CsrMatrix const&, std::__1::vector<double, std::__1::allocator<double>> const&, std::__1::vector<double, std::__1::allocator<double>>&) | 7531.0 | 99.64% |
| std::__1::mersenne_twister_engine<unsigned int, 32ul, 624ul, 397ul, 31ul, 2567483615u, 11ul, 4294967295u, 7ul, 2636928640u, 15ul, 4022730752u, 18ul, 1812433253u>::operator()[abi... | 10.0 | 0.13% |
| _platform_memmove | 2.0 | 0.03% |
| std::__1::__vector_layout<double, std::__1::allocator<double>>::__end_ptr[abi:nqe230102]() | 2.0 | 0.03% |
| std::__1::__independent_bits_engine<std::__1::mersenne_twister_engine<unsigned int, 32ul, 624ul, 397ul, 31ul, 2567483615u, 11ul, 4294967295u, 7ul, 2636928640u, 15ul, 4022730752u... | 2.0 | 0.03% |
| 0x1011089c1 | 1.0 | 0.01% |
| 0x101173b49 | 1.0 | 0.01% |
| dyld4::PrebuiltLoader::map(Diagnostics&, dyld4::RuntimeState&, dyld4::Loader::LoadOptions const&, bool) const | 1.0 | 0.01% |

## omp1

样本数：9954；累计采样权重：9954.0 ms；采样到的线程数：8。

| 热点（栈顶 Self Weight） | 权重/ms | 占比 |
|---|---:|---:|
| spmv_omp_student_1(CsrMatrix const&, std::__1::vector<double, std::__1::allocator<double>> const&, std::__1::vector<double, std::__1::allocator<double>>&) (.omp_outlined_debug__) | 9481.0 | 95.25% |
| __psynch_cvwait | 148.0 | 1.49% |
| __psynch_cvsignal | 117.0 | 1.18% |
| int __kmp_dispatch_next_algorithm<int>(int, dispatch_private_info_template<int>*, dispatch_shared_info_template<int> volatile*, int*, int*, int*, traits_t<int>::signed_t*, int, ... | 87.0 | 0.87% |
| __kmpc_dispatch_next_4 | 14.0 | 0.14% |
| std::__1::mersenne_twister_engine<unsigned int, 32ul, 624ul, 397ul, 31ul, 2567483615u, 11ul, 4294967295u, 7ul, 2636928640u, 15ul, 4022730752u, 18ul, 1812433253u>::operator()[abi... | 11.0 | 0.11% |
| mach_absolute_time | 11.0 | 0.11% |
| kmp_flag_64<false, true>::wait(kmp_info*, int, void*) | 10.0 | 0.10% |

## thread

样本数：9842；累计采样权重：9842.0 ms；采样到的线程数：9315。

| 热点（栈顶 Self Weight） | 权重/ms | 占比 |
|---|---:|---:|
| spmv_std_thread(CsrMatrix const&, std::__1::vector<double, std::__1::allocator<double>> const&, std::__1::vector<double, std::__1::allocator<double>>&, int)::$_0::operator()() c... | 8919.0 | 90.62% |
| __bsdthread_create | 150.0 | 1.52% |
| _kernelrpc_mach_vm_deallocate_trap | 107.0 | 1.09% |
| _platform_memset | 106.0 | 1.08% |
| __ulock_wait | 91.0 | 0.92% |
| _pthread_create | 75.0 | 0.76% |
| _pthread_tsd_cleanup | 61.0 | 0.62% |
| __ulock_wake | 61.0 | 0.62% |
